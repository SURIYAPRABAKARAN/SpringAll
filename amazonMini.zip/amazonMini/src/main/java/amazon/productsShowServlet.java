package amazon;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//class beanForShowProducts{
//	private String Pname;
//	private String Psize;
//	private String Pprice;
//	public String getPname() {
//		return Pname;
//	}
//	public void setPname(String Pname) {
//		this.Pname = Pname;
//	}
//	public String getPsize() {
//		return Psize;
//	}
//	public void setPsize(String Psize) {
//		this.Psize = Psize;
//	}
//	public String getPprice() {
//		return Pprice;
//	}
//	public void setPprice(String Pprice) {
//		this.Pprice = Pprice;
//	}
//
//}

@WebServlet("/productsShowServlet")
public class productsShowServlet extends HttpServlet {

	// beanForShowProducts beanObj = new beanForShowProducts();

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try (PrintWriter out = response.getWriter()) {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3307/suriya", "root", "Suriya@123");
			PreparedStatement stmt =  conn
					.prepareStatement("select * from amazonProductsDetails");

			ResultSet rs = stmt.executeQuery();
			response.setContentType("text/html");
			out.println("<table border='1'>");	
			while (rs.next()) {
				out.println("<tr>");
				out.println("<td>"+rs.getString("Pname")+"</td>");
				out.println("<td>"+rs.getString("Psize")+"</td>");
				out.println("<td>"+rs.getString("Pprice")+"</td>");
				out.println("</tr>");
			}
			out.println("</table>");

//			Statement productsState = (Statement) conn.createStatement();
//			ResultSet rs = ((java.sql.Statement) productsState).executeQuery("select * from amazonProductsDetails");
			// List<beanForShowProducts> productsShowList = new
			// ArrayList<beanForShowProducts>();

//			while(rs.next())
//			{
//				beanObj.setPname(rs.getString("Pname"));
//				beanObj.setPsize(rs.getString("Psize"));
//				beanObj.setPprice(rs.getString("Pprice"));
//				productsShowList.add(beanObj);
//			}
//			out.println("Pname" + "Psize" + "Pprice");
//			for( beanForShowProducts foreach: productsShowList)
//			{
//				out.println(foreach.getPname()+" "+foreach.getPsize()+" " + foreach.getPprice());
//			}
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
