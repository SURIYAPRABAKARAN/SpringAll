package amazon;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.cj.Session;

@WebServlet("/userLoginPageServlet")
public class userLoginPageServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String na = request.getParameter("Uname");
		String pa = request.getParameter("Upass");

//		if (Uname.equals("suriya") && Upass.equals("suriya@123")) {
//			response.sendRedirect("Home.jsp");
//		} else {
//			response.sendRedirect("index.jsp");
//		}
		HttpSession session = request.getSession();
		
		
		try (PrintWriter out = response.getWriter()) {
			Class.forName("com.mysql.jdbc.Driver");
			Connection Con = DriverManager.getConnection("jdbc:mysql://localhost:3307/suriya", "root", "Suriya@123");
			PreparedStatement ps = Con.prepareStatement("select * from amazonUserDetails where Username=? and Userpassword=?");

			ps.setString(1, na);
			ps.setString(2, pa);

			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				session.setAttribute("k", na);
				response.setContentType("text/html");
				RequestDispatcher rqd = request.getRequestDispatcher("productsShow.jsp");
				rqd.include(request, response);
				out.println("<p style=\"color: black; font-size: 30px;\">login successfully </p>");
			} else {
				response.setContentType("text/html");
				RequestDispatcher rqd = request.getRequestDispatcher("userLoginPage.jsp");
				rqd.include(request, response);
				out.println("<p style=\"color: black; font-size: 30px;\">invalid id</p>");			}
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		}

	}

}
