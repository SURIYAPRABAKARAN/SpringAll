package amazon;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/updateServlet")
public class updateServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String ProductName = request.getParameter("NewProductName");
		String ProductSize = request.getParameter("NewProductSize");
		String ProductPrice = request.getParameter("NewProductPrice");

		try (PrintWriter out = response.getWriter()) {
			Class.forName("com.mysql.jdbc.Driver");
			Connection Con = DriverManager.getConnection("jdbc:mysql://localhost:3307/suriya", "root", "Suriya@123");
			PreparedStatement ps = Con.prepareStatement("update amazonProductsDetails set Pprice ='"+ProductPrice+"' where Pname = '"+ProductName+"'");
			PreparedStatement ps1 = Con.prepareStatement("update amazonProductsDetails set Psize ='"+ProductSize+"' where Pname = '"+ProductName+"'");

			int n = ps.executeUpdate();
			int n1 = ps1.executeUpdate();

			if(n >= 1 || n1 >=1)
			{
				response.setContentType("text/html");
				RequestDispatcher rqd = request.getRequestDispatcher("adminMainPage.jsp");
				rqd.include(request, response);
				out.println(" <p style=\"color: black; font-size: 30px;\"> update successfully </P>");
			}
			else if(n == 0 || n1 == 0)
			{
				response.setContentType("text/html");
				RequestDispatcher rqd = request.getRequestDispatcher("update.jsp");
				rqd.include(request, response);
				out.println(" <p style=\"color: black; font-size: 30px;\">not change</P>");
			}
			
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
