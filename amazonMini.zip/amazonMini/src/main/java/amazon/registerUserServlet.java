package amazon;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class registerUserServlet
 */
@WebServlet("/registerUserServlet")
public class registerUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {			

    		String na = request.getParameter("Uname");
    		String pa = request.getParameter("Upass");

//    		if (Uname.equals("suriya") && Upass.equals("suriya@123")) {
//    			response.sendRedirect("Home.jsp");
//    		} else {
//    			response.sendRedirect("index.jsp");
//    		}

    		try(PrintWriter out =response.getWriter()){
    			Class.forName("com.mysql.jdbc.Driver");
    			Connection Con = DriverManager.getConnection("jdbc:mysql://localhost:3307/suriya", "root", "Suriya@123");
    			java.sql.Statement s=Con.createStatement();	
    			
    			int value= s.executeUpdate("insert into amazonUserDetails (Username,Userpassword) values ('"+na+"','"+pa+"')") ;
    			if(value == 1)
    			{
    				response.setContentType("text/html");
    				RequestDispatcher rqd = request.getRequestDispatcher("userLoginPage.jsp");
    				rqd.include(request, response);
    				out.println("<P style=\"color: white; font-size: 50px;\">register success successfully<p>");
    			}
    			else
    			{
    				out.println("Not register");
    			}
    		} catch (ClassNotFoundException e) {
    			System.out.println(e);
    		} catch (SQLException e) {
    			System.out.println(e);
    		} catch (Exception e) {
    			System.out.println(e);
    		}
	}

}
