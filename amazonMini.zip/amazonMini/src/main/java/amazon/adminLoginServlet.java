package amazon;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/adminLoginServlet")
public class adminLoginServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String adminUserName = request.getParameter("AUname");
		String adminUserPass = request.getParameter("AUpass");
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		response.setContentType("text/html");
		session.setAttribute("name", adminUserName);

		if (adminUserName.equals("admin") && adminUserPass.equals("admin123")) {

			response.sendRedirect("adminMainPage.jsp");
		} else {
			response.setContentType("text/html");
			RequestDispatcher rqd = request.getRequestDispatcher("adminLogin.jsp");
			rqd.include(request, response);
			out.println("<p style=\"color: white;font-size: 30px; margin-left: 700px;\">invalid inputs</p>");
		}
	}
}