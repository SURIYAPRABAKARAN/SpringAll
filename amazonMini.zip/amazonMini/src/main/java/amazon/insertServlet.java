package amazon;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/insertServlet")
public class insertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String ProductName = request.getParameter("NewProductName");
		String ProductPrice = request.getParameter("NewProductPrice");
		String ProductSize = request.getParameter("NewProductSize");

		try(PrintWriter out =response.getWriter()){
			Class.forName("com.mysql.jdbc.Driver");
			Connection Con = DriverManager.getConnection("jdbc:mysql://localhost:3307/suriya", "root", "Suriya@123");
			java.sql.Statement s=Con.createStatement();	
			
			int value= s.executeUpdate("insert into amazonProductsDetails (Pname,Psize,Pprice) values ('"+ProductName+"','"+ProductSize+"','"+ProductPrice+"')") ;
			if(value == 1)
			{
				response.setContentType("text/html");
				RequestDispatcher rqd = request.getRequestDispatcher("adminMainPage.jsp");
				rqd.include(request, response);
				out.println(" <p style=\"color: black; font-size: 30px;\"> insert successfully </P>");			}
			else {
				response.setContentType("text/html");
				RequestDispatcher rqd = request.getRequestDispatcher("insert.jsp");
				rqd.include(request, response);
				out.println(" <p style=\"color: black; font-size: 30px;\">not change</P>");			}
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
