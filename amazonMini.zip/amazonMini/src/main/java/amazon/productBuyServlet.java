package amazon;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/productBuyServlet")
public class productBuyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String productBuy = request.getParameter("productbuy");

		try (PrintWriter out = response.getWriter()) {
			Class.forName("com.mysql.jdbc.Driver");
			Connection Conn = DriverManager.getConnection("jdbc:mysql://localhost:3307/suriya", "root", "Suriya@123");
			PreparedStatement ps = Conn.prepareStatement("select * from amazonProductsDetails where Pname=?");
			ps.setString(1, productBuy);
			PreparedStatement ps1 = Conn
					.prepareStatement("delete from amazonProductsDetails where Pname='" + productBuy + "'");
			ResultSet rs = ps.executeQuery();
			ps1.executeUpdate();

			if (rs.next()) {
				response.setContentType("text/html");
				RequestDispatcher rqd = request.getRequestDispatcher("productsShow.jsp");
				rqd.include(request, response);
				out.println("successfully");

			} else {
				out.println("enter correct input");
			}

		} catch (ClassNotFoundException e) {
			System.out.println(e);
		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
