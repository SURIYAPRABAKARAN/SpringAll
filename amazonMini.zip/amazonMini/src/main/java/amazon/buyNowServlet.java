package amazon;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/buyNowServlet")
public class buyNowServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

String Productname = request.getParameter("pname");
		
		try (PrintWriter out = response.getWriter()) {
			Class.forName("com.mysql.jdbc.Driver");
			Connection Con = DriverManager.getConnection("jdbc:mysql://localhost:3307/suriya", "root", "Suriya@123");
			PreparedStatement ps = Con.prepareStatement("delete from amazonProductsDetails where Pname ='"+Productname+"'");
			
			int n = ps.executeUpdate();
			
			if(n >= 1)
			{
				response.setContentType("text/html");
				RequestDispatcher rqd = request.getRequestDispatcher("productsShow.jsp");
				rqd.include(request, response);
				out.println("<p style=\"color: black; font-size: 30px; margin-left:300px;\">buy successfully </p>");
			}
			else if(n == 0)
			{
				response.setContentType("text/html");
				RequestDispatcher rqd = request.getRequestDispatcher("BuyNow.jsp");
				rqd.include(request, response);
				out.println("<p style=\"color: black; font-size: 30px;\">not buy </p>");
			}
			
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		}
	
		
	}

}
