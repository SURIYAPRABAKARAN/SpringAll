package sample;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class registerServlet
 */
@WebServlet("/registerServlet")
public class registerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		

    		String na = request.getParameter("Uname");
    		String pa = request.getParameter("Upass");

//    		if (Uname.equals("suriya") && Upass.equals("suriya@123")) {
//    			response.sendRedirect("Home.jsp");
//    		} else {
//    			response.sendRedirect("index.jsp");
//    		}

    		try(PrintWriter out =response.getWriter()){
    			Class.forName("com.mysql.jdbc.Driver");
    			Connection Con = DriverManager.getConnection("jdbc:mysql://localhost:3307/suriya", "root", "Suriya@123");
    			java.sql.Statement s=Con.createStatement();	
    			
    			int value= s.executeUpdate("insert into projectFlowTable (name,password) values ('"+na+"','"+pa+"')") ;
    			if(value == 1)
    			{
    				response.sendRedirect("index.jsp");
    				out.println("Register successfully now you can logi..!");
    			}
    		} catch (ClassNotFoundException e) {
    			System.out.println(e);
    		} catch (SQLException e) {
    			System.out.println(e);
    		} catch (Exception e) {
    			System.out.println(e);
    		}
    	}
    		
    	}

	