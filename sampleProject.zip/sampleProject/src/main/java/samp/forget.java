package samp;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/forget")
public class forget extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String userName = request.getParameter("Uname");
		String userPass = request.getParameter("Upass");
		String userPassC = request.getParameter("UpassC");

		try (PrintWriter out = response.getWriter()) {
			Class.forName("com.mysql.jdbc.Driver");
			Connection Con = DriverManager.getConnection("jdbc:mysql://localhost:3307/suriya", "root", "Suriya@123");
			PreparedStatement ps = Con.prepareStatement("update projectFlowTable set password = ? where name = ?");
			ps.setString(1,userPassC);
			ps.setString(2,userName);
			
			int n = ps.executeUpdate();
			
			if(n >= 1)
			{
				out.println("Password changed");
			}
			else if(n == 0)
			{
				out.println("Password not changed");
			}
			
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
